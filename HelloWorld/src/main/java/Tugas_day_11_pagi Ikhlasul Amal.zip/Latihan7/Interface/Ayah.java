package Latihan7.Interface;

import Latihan7.Interface.Kakek;

public interface Ayah extends Kakek {
    public default void namaAyah(String namaAyah) {
    }

    public default void sifatAyah(String sifatAyah) {
    }
}
