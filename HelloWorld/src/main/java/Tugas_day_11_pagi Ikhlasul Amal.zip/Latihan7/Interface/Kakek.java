package Latihan7.Interface;

interface Kakek {
    public default void namaKakek(String namaKakek) {
    }
}
