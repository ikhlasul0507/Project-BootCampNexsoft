package Latihan7.Interface;

public interface Ibu {
    public default void namaIbu(String namaIbu) {
    }

    public default void sifatIbu(String sifatIbu) {
    }
}
