package Latihan7;

import Latihan7.Class.Anak;

public class Main {
    public static void main(String[] args) {
        Anak an = new Anak();
        an.namaAnak();
    }
}
