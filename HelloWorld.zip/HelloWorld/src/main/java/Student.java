//buat kelas student
class Student{
    int rollno;
    String name;
    int age;
    //method constructor untuk kelas student
    Student(int rollno, String name, int age){
        this.rollno = rollno;
        this.name = name;
        this.age = age;
    }
}