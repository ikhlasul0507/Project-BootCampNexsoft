package ExampleMultithreading;

public class Multi3 implements Runnable {
    public void run() {
        System.out.println("thread is running....");
    }

    public static void main(String[] args) {
        Multi3 ml = new Multi3();
        Thread t1 = new Thread(ml);
        t1.start();
    }
}
