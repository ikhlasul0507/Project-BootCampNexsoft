package com.exam.starbucks.Service;

import com.exam.starbucks.Model.Product;
import com.exam.starbucks.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("productService")
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductRepository productRepository;

    @Override
    public void saveProduct(Product product) {
        synchronized (this) {
            productRepository.saveProduct(product);
        }
    }

    @Override
    public List<Product> findAllProduct() {
        return productRepository.findAllProduct();
    }

    @Override
    public Product findByCodeProduct(String codeProduct) {
        Product product;
        try {
            product = productRepository.findByCodeProduct(codeProduct);
        } catch (Exception e) {
            product = null;
        }
        return product;
    }

    @Override
    public Product findByNameProduct(String product) {
        Product product1;
        try {
            product1 = (Product) productRepository.findByNameProduct(product).get(0);
        } catch (Exception e) {
            product1 = null;
        }
        return product1;
    }

    @Override
    public Product findByCodeAndNameProduct(String codeProduct, String product) {
        Product product1;
        try {
            product1 = productRepository.findByCodeAndNameProduct(codeProduct, product);
        } catch (Exception e) {
            product1 = null;
        }
        return product1;
    }

    @Override
    public void updateDataProduct(String codeProduct, Product product) {
        synchronized (this) {
            productRepository.updateDataProduct(codeProduct, product);
        }
    }

    @Override
    public void deleteAllProduct() {
        productRepository.deleteAllProduct();
    }

    @Override
    public void deleteByCodeProduct(String codeProduct) {
        synchronized (this) {
            productRepository.deleteByCodeProduct(codeProduct);
        }
    }

    @Override
    public void deleteByNameProduct(String product) {
        synchronized (this) {
            productRepository.deleteByNameProduct(product);
        }
    }

    @Override
    public boolean isProductExist(Product product) {
        return productRepository.findByNameProduct(product.getProduct()).size() != 0;
    }
}
