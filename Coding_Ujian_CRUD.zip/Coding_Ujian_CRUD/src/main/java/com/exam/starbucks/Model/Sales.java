package com.exam.starbucks.Model;

import java.util.Date;
import java.util.List;

public class Sales {
    private String codeTransaction;
    private String customer;
    private Date transactionDate;
    List<Product> products;
    private double totalBelanja;
    private double ppn10percent;
    private double totalBelanjaAkhir;

    public Sales () {

    }

    public Sales(String codeTransaction, String customer, Date transactionDate, List<Product> products) {
        this.codeTransaction = codeTransaction;
        this.customer = customer;
        this.transactionDate = transactionDate;
        this.products = products;
    }

    public Sales(String codeTransaction, String customer, Date transactionDate, List<Product> products, double totalBelanja, double ppn10percent,
                 double totalBelanjaAkhir) {
        this.codeTransaction = codeTransaction;
        this.customer = customer;
        this.transactionDate = transactionDate;
        this.totalBelanja = totalBelanja;
        this.products = products;
        this.ppn10percent = ppn10percent;
        this.totalBelanjaAkhir = totalBelanjaAkhir;
    }

    public String getCodeTransaction() {
        return codeTransaction;
    }

    public void setCodeTransaction(String codeTransaction) {
        this.codeTransaction = codeTransaction;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public double getTotalBelanja() {
        return totalBelanja;
    }

    public void setTotalBelanja() {
        double totalBelanja = 0.0;
        for (int i = 0; i < products.size(); i++) {
            totalBelanja += products.get(i).getTotalHarga();
        }
        this.totalBelanja = totalBelanja;
    }

    public double getPpn10percent() {
        return ppn10percent;
    }

    public void setPpn10percent() {
        double ppn = getTotalBelanja() * (10.0 / 100.0);
        this.ppn10percent = ppn;
    }

    public double getTotalBelanjaAkhir() {
        return totalBelanjaAkhir;
    }

    public void setTotalBelanjaAkhir() {
        this.totalBelanjaAkhir = getPpn10percent() + getTotalBelanja();
    }

    @Override
    public String toString() {
        return "Sales{" +
                "codeTransaction='" + codeTransaction + '\'' +
                ", customer='" + customer + '\'' +
                ", transactionDate=" + transactionDate +
                ", products=" + products +
                '}';
    }
}
