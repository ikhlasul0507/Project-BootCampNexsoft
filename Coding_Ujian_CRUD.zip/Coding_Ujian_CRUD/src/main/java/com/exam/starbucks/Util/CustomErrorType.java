package com.exam.starbucks.Util;

public class CustomErrorType {

    //for pulling message error to response body API

    private String errorMessage;

    public CustomErrorType(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() {
        return errorMessage;
    }
}
