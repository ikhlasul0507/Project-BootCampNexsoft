package com.exam.starbucks.Repository;

import com.exam.starbucks.Model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository("productRepository")
public class ProductRepositoryImpl implements ProductRepository {

    @Autowired
    JdbcTemplate databases;

    @Override
    public void saveProduct(Product product) {
        String uuidRandom = UUID.randomUUID().toString();
        product.setCodeProduct(uuidRandom);
        String sql = "INSERT INTO productsb (codeProduct,product,price) VALUES (?,?,?)";
        databases.update(sql,
                product.getCodeProduct(),
                product.getProduct(),
                product.getPrice());
    }

    @Override
    public List<Product> findAllProduct() {
        String sql = "SELECT * FROM productsb";
        return databases.query(sql,
                (rs, rowNum) ->
                        new Product(
                                rs.getString("codeProduct"),
                                rs.getString("product"),
                                rs.getDouble("price")
                        ));
    }

    @Override
    public Product findByCodeProduct(String codeProduct) {
        String sql = "SELECT * FROM productsb WHERE codeProduct = '"+codeProduct+"'";
        return databases.queryForObject(sql,
                (rs, rowNum) ->
                    new Product(
                            rs.getString("codeProduct"),
                            rs.getString("product"),
                            rs.getDouble("price")
                    ));
    }

    @Override
    public List<Product> findByNameProduct(String product) {
        String sql = "SELECT * FROM productsb WHERE product LIKE ?";
        return databases.query(sql,
                new Object[]{"%"+product+"%"},
                (rs, rowNum) ->
                        new Product(
                                rs.getString("codeProduct"),
                                rs.getString("product"),
                                rs.getDouble("price")
                        ));
    }

    @Override
    public Product findByCodeAndNameProduct(String codeProduct, String product) {
        String sql = "SELECT * FROM productsb WHERE codeProduct ='"+codeProduct+"' AND product ='"+product+"'";
        return databases.queryForObject(sql,
                (rs, rowNum) ->
                        new Product(
                                rs.getString("codeProduct"),
                                rs.getString("product"),
                                rs.getDouble("price")
                        ));
    }

    @Override
    public void updateDataProduct(String codeProduct, Product product) {
        String sql = "UPDATE productsb\n" +
                "SET product = ?, price = ?\n" +
                "WHERE codeProduct = ?;";
        databases.update(sql, product.getProduct(), product.getPrice(), codeProduct);
    }

    @Override
    public void deleteAllProduct() {
        String sql = "DELETE FROM productsb";
        databases.execute(sql);
    }

    @Override
    public void deleteByCodeProduct(String codeProduct) {
        String sql = "DELETE FROM productsb WHERE codeProduct='"+codeProduct+"'";
        databases.execute(sql);
    }

    @Override
    public void deleteByNameProduct(String product) {
        String sql = "DELETE FROM productsb WHERE product='"+product+"'";
        databases.execute(sql);
    }
}
