package com.exam.starbucks.Service;

import com.exam.starbucks.Model.Product;
import com.exam.starbucks.Model.Sales;

import java.util.List;

public interface SalesService {

    //Place for CRUD and Manipulate the Data

    //Create the Data----------------------------------------
    void saveSales(Sales sales);

    //Read the Data------------------------------------------

    //Read All Data
    List<Sales> findAllSales();

    //Read the Data by id
    Sales findByCodeTransaction(String codeTransaction);

//    //Read the Data by name
//    Product findByNameProduct(String product);

    //Read the Data by Parameter (id,name,allId and name)
    Product findByCodeAndNameCustomer(String codeTransaction, String customer);

    //Update the Data----------------------------------------
    void updateDataSales(Sales sales);

    //Delete the Data----------------------------------------

//    //Delete All Data
//    void deleteAllProduct();

    //Delete the Data (1 Data) by id
    void deleteByCodeTransaction(String codeTransaction);

//    //Delete the Data (1 Data) by name
//    void deleteByNameProduct(String product);

//    //is Category Exist,-------------------------------------
//    //to check with name of Product parameter
//    boolean isProductExist(Product product);
}
