package com.exam.starbucks.Repository;

import com.exam.starbucks.Model.Product;

import java.util.List;

public interface ProductRepository {

    //Place for CRUD and Manipulate the Data

    //Create the Data----------------------------------------
    void saveProduct(Product product);

    //Read the Data------------------------------------------

    //Read All Data
    List<Product> findAllProduct();

    //Read the Data by id
    Product findByCodeProduct(String codeProduct);

    //Read the Data by name
    List<Product> findByNameProduct(String product);

    //Read the Data by Parameter (id,name,allId and name)
    Product findByCodeAndNameProduct(String codeProduct, String product);

    //Update the Data----------------------------------------
    void updateDataProduct(String codeProduct,Product product);

    //Delete the Data----------------------------------------

    //Delete All Data
    void deleteAllProduct();

    //Delete the Data (1 Data) by id
    void deleteByCodeProduct(String codeProduct);

    //Delete the Data (1 Data) by name
    void deleteByNameProduct(String product);
}
