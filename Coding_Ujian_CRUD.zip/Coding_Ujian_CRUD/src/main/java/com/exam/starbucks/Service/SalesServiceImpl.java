package com.exam.starbucks.Service;

import com.exam.starbucks.Model.Product;
import com.exam.starbucks.Model.Sales;
import com.exam.starbucks.Repository.SalesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("salesService")
public class SalesServiceImpl implements SalesService {

    @Autowired
    SalesRepository salesRepository;

    @Override
    public void saveSales(Sales sales) {
        synchronized (this) {
            salesRepository.saveSales(sales);
        }
    }

    @Override
    public List<Sales> findAllSales() {
        return salesRepository.findAllSales();
    }

    @Override
    public Sales findByCodeTransaction(String codeTransaction) {
        Sales obj;
        try {
            obj = salesRepository.findByCodeTransaction(codeTransaction);
        } catch (Exception e) {
            obj = null;
        }
        return obj;
    }

    @Override
    public Product findByCodeAndNameCustomer(String codeTransaction, String customer) {
        return null;
    }

    @Override
    public void updateDataSales(Sales sales) {
        synchronized (this) {
            salesRepository.updateDataSales(sales);
        }
    }

    @Override
    public void deleteByCodeTransaction(String codeTransaction) {
        synchronized (this) {
            salesRepository.deleteByCodeTransaction(codeTransaction);
        }
    }
}
