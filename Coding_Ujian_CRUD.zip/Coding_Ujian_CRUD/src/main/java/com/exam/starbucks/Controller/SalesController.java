package com.exam.starbucks.Controller;

import com.exam.starbucks.Model.Sales;
import com.exam.starbucks.Service.SalesService;
import com.exam.starbucks.Util.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/coffee")
public class SalesController {

    public static final Logger logger = LoggerFactory.getLogger(SalesController.class);

    @Autowired
    SalesService salesService;

    //Create Product Data---------------------------------------------------------------------
    @RequestMapping(value = "/sales/create/", method = RequestMethod.POST)
    public ResponseEntity<?> createSales(@RequestBody Sales sales) {
        logger.info("Creating sales : {}", sales);
        salesService.saveSales(sales);
        Sales currentSales = salesService.findByCodeTransaction(sales.getCodeTransaction());
        return new ResponseEntity<>(currentSales, HttpStatus.CREATED);
    }

    //Show All Data---------------------------------------------------------------------------
    @RequestMapping(value = "/sales/all/", method = RequestMethod.GET)
    public ResponseEntity<List<Sales>> showSales() {
        List<Sales> salesList = salesService.findAllSales();
        if (salesList.isEmpty()) {
            return new ResponseEntity<>(salesList, HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(salesList, HttpStatus.OK);
        }
    }

    //Show Data By ID-------------------------------------------------------------------------
    @RequestMapping(value = "/sales/{code}", method = RequestMethod.GET)
    public ResponseEntity<?> showCartById(@PathVariable("code") String codeTransaction) {
        logger.info("Fetching Sales with codeTransaction {}", codeTransaction);
        Sales sales = salesService.findByCodeTransaction(codeTransaction);
        if (sales == null) {
            logger.error("Sales with codeTransaction {} not found.", codeTransaction);
            return new ResponseEntity<>(new CustomErrorType("Sales with codeTransaction " + codeTransaction + " not found."), HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(sales, HttpStatus.OK);
        }
    }

    //Update Data-----------------------------------------------------------------------------
    //Update Sales Detail Data----------------------------------------------------------------
    @RequestMapping(value = "/sales/update/", method = RequestMethod.PUT)
    public ResponseEntity<?> updateSalesDetail(@RequestBody Sales sales) {
        logger.info("Updating Sales with id {}", sales.getCodeTransaction());

        Sales currentSales = salesService.findByCodeTransaction(sales.getCodeTransaction());

        if (currentSales == null) {
            logger.error("Unable to update. Sales with id {} not found.", sales.getCodeTransaction());
            return new ResponseEntity<>(new CustomErrorType("Unable to update. Sales with id " + sales.getCodeTransaction() + " not found."),
                    HttpStatus.NOT_FOUND);
        } else {
            salesService.updateDataSales(sales);
            Sales newUpdate = salesService.findByCodeTransaction(sales.getCodeTransaction());
            return new ResponseEntity<>(newUpdate, HttpStatus.CREATED);
        }
    }

    //Delete Data By Id-----------------------------------------------------------------------
    @RequestMapping(value = "/sales/delete/", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteSingleSalesById(@RequestParam("code") String codeTransaction) {
        logger.info("Delete Sales with codeTransaction {} ...", codeTransaction);

        Sales findingId = salesService.findByCodeTransaction(codeTransaction);
        if (findingId == null) {
            logger.error("Unable to deleting that sales, because sales id {} is not found", codeTransaction);
            return new ResponseEntity<>(new CustomErrorType("Unable to deleting that Sales "+codeTransaction+" , because not found"), HttpStatus.NOT_FOUND);
        } else {
            salesService.deleteByCodeTransaction(codeTransaction);
            return new ResponseEntity<>(HttpStatus.OK);
        }
    }
}
