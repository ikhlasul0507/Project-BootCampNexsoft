package com.exam.starbucks.Repository;

import com.exam.starbucks.Model.Product;
import com.exam.starbucks.Model.Sales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Repository("salesRepository")
public class SalesRepositoryImpl implements SalesRepository {

    @Autowired
    JdbcTemplate databases;

    @Override
    public void saveSales(Sales sales) {
        String uuidRandom = UUID.randomUUID().toString();
        sales.setCodeTransaction(uuidRandom);
        sales.setTransactionDate(new Date());
        String sql = "INSERT INTO sales(codeTransaction,customer,transactionDate) VALUES(?,?,?)";
        databases.update(sql,
                sales.getCodeTransaction(),
                sales.getCustomer(),
                sales.getTransactionDate()
        );

        List<Product> products = sales.getProducts();
        for (int i = 0; i < products.size(); i++) {
            String uuidRandom1 = UUID.randomUUID().toString();
            String sql1 = "INSERT INTO salesdetail(codeDetail,codeTransaction,codeProduct,qty) VALUES(?,?,?,?)";
            databases.update(sql1,
                    uuidRandom1,
                    sales.getCodeTransaction(),
                    products.get(i).getCodeProduct(),
                    products.get(i).getQty());
        }
    }

    @Override
    public List<Sales> findAllSales() {
        String sql = "SELECT * FROM sales";
        List<Sales> salesList;
        salesList = databases.query(sql,
                (rs, rowNum) ->
                        new Sales(
                                rs.getString("codeTransaction"),
                                rs.getString("customer"),
                                rs.getDate("transactionDate"),
                                null,
                                0.0,
                                0.0,
                                0.0
                        )
        );
        for (Sales sl : salesList) {
            String sql1 = "SELECT d.codeProduct,p.product,p.price,d.qty,(p.price*d.qty)as totalHarga FROM salesdetail d INNER JOIN productsb p ON d.codeProduct = p.codeProduct AND codeTransaction=?";
            sl.setProducts(databases.query(sql1,
                    preparedStatement -> preparedStatement.setString(1, sl.getCodeTransaction()),
                    (rs, rowNum) ->
                            new Product(
                                    rs.getString("codeProduct"),
                                    rs.getString("product"),
                                    rs.getDouble("price"),
                                    rs.getInt("qty"),
                                    rs.getDouble("totalHarga")
                            )
            ));
            sl.setTotalBelanja();
            sl.setPpn10percent();
            sl.setTotalBelanjaAkhir();
        }
        return salesList;
    }

    @Override
    public Sales findByCodeTransaction(String codeTransaction) {
        Sales sales;
        String sql = "SELECT * FROM sales WHERE codeTransaction=?";
        sales = databases.query(sql,
                preparedStatement -> preparedStatement.setString(1,codeTransaction),
                (rs, rowNum) ->
                        new Sales(
                                rs.getString("codeTransaction"),
                                rs.getString("customer"),
                                rs.getDate("transactionDate"),
                                null,
                                0.0,
                                0.0,
                                0.0
                        )).get(0);
        String sql1 = "SELECT d.codeProduct,p.product,p.price,d.qty,(p.price*d.qty)as totalHarga FROM salesdetail d INNER JOIN productsb p ON d.codeProduct = p.codeProduct AND codeTransaction=?";
        sales.setProducts(databases.query(sql1,
                preparedStatement -> preparedStatement.setString(1,sales.getCodeTransaction()),
                (rs, rowNum) ->
                        new Product(
                                rs.getString("codeProduct"),
                                rs.getString("product"),
                                rs.getDouble("price"),
                                rs.getInt("qty"),
                                rs.getDouble("totalHarga")
                        ))
        );
        sales.setTotalBelanja();
        sales.setPpn10percent();
        sales.setTotalBelanjaAkhir();
        return sales;
    }

    @Override
    public Product findByCodeAndNameCustomer(String codeTransaction, String customer) {
        return null;
    }

    @Override
    public void updateDataSales(Sales sales) {
        String sql = "DELETE FROM salesdetail WHERE codeTransaction=?";
        databases.update(sql,sales.getCodeTransaction());

        List<Product> products = sales.getProducts();
        for (int i = 0; i < products.size(); i++) {
            String uuidRandom = UUID.randomUUID().toString();
            Product product = products.get(i);
            String sql1 = "INSERT INTO salesdetail (codeDetail, codeTransaction, codeProduct, qty) VALUES (?,?,?,?)";
            databases.update(sql1,uuidRandom,sales.getCodeTransaction(),products.get(i).getCodeProduct(),products.get(i).getQty());
        }
    }

    @Override
    public void deleteByCodeTransaction(String codeTransaction) {
        String sql = "DELETE FROM sales WHERE codeTransaction='"+codeTransaction+"'";
        databases.execute(sql);
    }
}
