package com.exam.starbucks.Model;

public class Product {
    private String codeProduct;
    private String product;
    private double price;
    private int qty;
    private double totalHarga;

    public Product(){

    }

    public Product(String codeProduct, String product, double price) {
        this.codeProduct = codeProduct;
        this.product = product;
        this.price = price;
    }

    public Product(String codeProduct, String product, double price, int qty, double totalHarga) {
        this.codeProduct = codeProduct;
        this.product = product;
        this.price = price;
        this.qty = qty;
        this.totalHarga = totalHarga;
    }

    public String getCodeProduct() {
        return codeProduct;
    }

    public void setCodeProduct(String codeProduct) {
        this.codeProduct = codeProduct;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getTotalHarga() {
        return getPrice()*getQty();
    }

    public void setTotalHarga(double totalHarga) {
        this.totalHarga = totalHarga;
    }

    @Override
    public String toString() {
        return "Product{" +
                "codeProduct='" + codeProduct + '\'' +
                ", product='" + product + '\'' +
                ", price=" + price +
                '}';
    }
}
